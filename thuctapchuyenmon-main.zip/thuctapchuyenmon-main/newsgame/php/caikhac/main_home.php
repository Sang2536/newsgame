
<!-- begin main_home -->
<div class="row">
            <div class="col l-12 m-12 c-12">
                <div class="card" style="width: 100%; height:500px;">
                    <img class="card-img-top" style="width: 100%; height:450px;" src="https://gameviet.mobi/wp-content/uploads/2020/02/download-hinh-nen-lien-quan-mobile-gameviet.mobi_-1280x640.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h3 class="card-title">Card title</h3>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row center">
            <div class="col l-9 m-12 c-12">

                <div class="row">
                    <div class="col l-12 m-12 c-12 top_title">
                        <h3>Games</h3>
                    </div>
                </div>

                <div class="row">
                    <div class="col l-3 m-6 c-12">
                        <h3>play the most</h3>
                    </div>
                </div>

                <div class="row">
                    <div class="col l-3 m-6 c-6 game_image">
                        <a>
                            <img class="card-img-top" style="width: 100%; height:150px;" src="http://cdn.gametv.vn/gtv-photo/GTVNews/1592889429/api_cdn.gametv.vn-a015707d9c2a117b538d24dc811f0d5f.png" alt="Card image cap">
                            <h3>Liên quân</h3>
                        </a>
                    </div>
                    <div class="col l-3 m-6 c-6 game_image">
                        <a>
                            <img class="card-img-top" style="width: 100%; height:150px;" src="http://cdn.gametv.vn/gtv-photo/GTVNews/1592889429/api_cdn.gametv.vn-a015707d9c2a117b538d24dc811f0d5f.png" alt="Card image cap">
                            <h3>Liên quân</h3>
                        </a>
                    </div>
                    <div class="col l-3 m-6 c-6 game_image">
                        <a>
                            <img class="card-img-top" style="width: 100%; height:150px;" src="http://cdn.gametv.vn/gtv-photo/GTVNews/1592889429/api_cdn.gametv.vn-a015707d9c2a117b538d24dc811f0d5f.png" alt="Card image cap">
                            <h3>Liên quân</h3>
                        </a>
                    </div>
                    <div class="col l-3 m-6 c-6 game_image">
                        <a>
                            <img class="card-img-top" style="width: 100%; height:150px;" src="http://cdn.gametv.vn/gtv-photo/GTVNews/1592889429/api_cdn.gametv.vn-a015707d9c2a117b538d24dc811f0d5f.png" alt="Card image cap">
                            <h3>Liên quân</h3>
                        </a>
                    </div>
                </div>

                <div class="row">
                    <div class="col l-3 m-6 c-12">
                        <h3>just released</h3>
                    </div>
                </div>
                <div class="row">

                    <div class="col l-3 m-6 c-6 game_image">
                        <a>
                            <img class="card-img-top" style="width: 100%; height:150px;" src="http://cdn.gametv.vn/gtv-photo/GTVNews/1592889429/api_cdn.gametv.vn-a015707d9c2a117b538d24dc811f0d5f.png" alt="Card image cap">
                            <h3>Liên quân</h3>
                        </a>
                    </div>
                    <div class="col l-3 m-6 c-6 game_image">
                        <a>
                            <img class="card-img-top" style="width: 100%; height:150px;" src="http://cdn.gametv.vn/gtv-photo/GTVNews/1592889429/api_cdn.gametv.vn-a015707d9c2a117b538d24dc811f0d5f.png" alt="Card image cap">
                            <h3>Liên quân</h3>
                        </a>
                    </div>
                    <div class="col l-3 m-6 c-6 game_image">
                        <a>
                            <img class="card-img-top" style="width: 100%; height:150px;" src="http://cdn.gametv.vn/gtv-photo/GTVNews/1592889429/api_cdn.gametv.vn-a015707d9c2a117b538d24dc811f0d5f.png" alt="Card image cap">
                            <h3>Liên quân</h3>
                        </a>
                    </div>
                    <div class="col l-3 m-6 c-6 game_image">
                        <a>
                            <img class="card-img-top" style="width: 100%; height:150px;" src="http://cdn.gametv.vn/gtv-photo/GTVNews/1592889429/api_cdn.gametv.vn-a015707d9c2a117b538d24dc811f0d5f.png" alt="Card image cap">
                            <h3>Liên quân</h3>
                        </a>
                    </div>
                </div>

            </div>
            <div class="col l-3 m-12 c-12">
                <div class="row right">
                    <div class="col l-12 m-12 c-12">
                        <h3>CATEGORY GAMES</h3>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link disabled" href="#">In-game terminology</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="#">Just released</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Hot</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Online</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link disabled" href="#">Ofline</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link disabled" href="#">Laptop</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link disabled" href="#">Mobile</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link disabled" href="#">Giftcode</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row right">
                    <div class="col l-12 m-12 c-12">
                        <h1>l-12 m-12 c-12 - Thông báo của web</h1>
                    </div>
                </div>
                <div class="row right">
                    <div class="col l-12 m-12 c-12">
                        <form>
                            <h1>Đăng Ký</h1>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Confirm Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

<!-- end main_home -->