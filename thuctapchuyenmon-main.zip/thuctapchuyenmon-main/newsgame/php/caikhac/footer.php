<!-- footer -->    
    <div class="container"></div>
        <div class="row">
            <div class="col l-12 m-12 c-12">
                <img style="width: 100%; height: 200px;" src="https://image.freepik.com/free-vector/digital-neon-game-banner_1017-19897.jpg" alt="end game">
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <h3>About Us</h3>
                    <p>We bring the most accurate and fastest news possible to you</p>
                    <p>Hope what we do can help you in some way.</p>
                    <p>Thank you for coming to us</p>
                </div>
                <div class="col-sm-4">
                    <h3>Tutorial</h3>
                    <p><a href="">Home</a></p>
                    <p><a href="">Image game</a></p>
                    <p><a href="">News</a></p>
                    <p><a href="">Category game</a></p>
                </div>
                <div class="col-sm-4">
                    <h3>Contact</h3>
                    <p>Email: dovansang2536@gmail.com</p>
                    <p>Phone Number: 1234567890</p>
                    <p>Group Facebook: news game (null)</p>
                </div>
            </div>
        </div>
        
    </div>
</body>

</html>