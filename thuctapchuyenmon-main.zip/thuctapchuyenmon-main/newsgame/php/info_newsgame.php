I. Admin
    1. Thiết kế database
    2. Phát triển quản lý danh mục bài viết 
    3. Phát triển quản lý bài viết
    4. Phát triển quản lý danh mục hình ảnh
    5. Phát triển quản lý hình ảnh
    6. Phát triển quản lý danh mục sản phẩm game 
    7. Phát triển quản lý sản phẩm game

II. Frontend
    1. Home
    2. Danh mục bài viết
    3. Chi tiết bài viết
    4. Danh mục hình ảnh
    5. Chi tiết hình ảnh
    6. Danh mục sản phẩm game
    7. Chi tiết sản phẩm game

III. Tối ưu giao diện (UI & UX)
    1. Chia ra từng phần: menu_main.php, slider_start.php, content.php, banner_eng.php footer.php
    2. Ghép các phần lại với nhau thành trang hoàn chỉnh: home.php, daily_life.php, picture.php, ...
    3. Xử lý phần backend (lấy dữ liệu xuống front end) cũng chia theo từng phần

IV. Việc chưa làm
    1. Đăng nhập được vào trang chỉ định cho cả user và admin
    2. Làm sao để user, admin bình luận trong bài viết
    3. Chia nhỏ ra từng phần, ghép lại được và hiển thị như lúc chưa chia nhỏ
    4. Làm sao để thêm, xóa, sửa chỉ trong 1 trang

V. Hoàn thành
    1. Kiểm tra lại tất cả hệ thống wesite(có lỗi không, giao diện ổn không, dữ liệu đủ chưa)
    2. Kiểm tra lại word, powpoint
    3. Thầy cô có thể hỏi những gì, nên trả lời thế nào cho ổn nếu không biết.


VI. Chưa thành cơ bản 
    1. adminítration: 
        ad_category_image.php
        ad_category_add.php
        ad_category_update.php
        ad_category_remove.php
    2. user
        gamers_streamers.php
        image.php 
        tournaments.php
    3. Chức năng trong các trang 
        Phân trang tự động (Pagination - bootstrap)
        Bắt buộc đăng nhập admin mới vào trang kế được, user mới có thể bình luận
        Click/ rê chuột vào vùng đánh dấu se hiện thông báo cạnh vùng đó (Tooltips/ Toasts)
        click button sẽ làm gì đó (có thể nhiều) trong cùng 1 trang (Collapse)

    4. 7/6/2021
        1. Làm word chi tiết
        2. Làm phân trang cho news/ image 
        3. Nộp lên githtb trước 17h00